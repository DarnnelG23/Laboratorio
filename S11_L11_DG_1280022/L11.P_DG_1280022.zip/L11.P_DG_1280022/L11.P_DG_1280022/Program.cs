﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace PruebaVector
{
    class PruebaV
    {
        int aprobadosSeccion1 = 0, desaprobadosSeccion1 = 0;
        int aprobadosSeccion2 = 0, desaprobadosSeccion2 = 0;
        int seccion1y2Aprobados = 0, seccion1y2Desaprobados = 0;
        int promedioSeccion1y2 = 0;
        int promedio1 = 0, promedio2 = 0;
        int sobresalientes = 0, notaRegular = 0;
        private int[] seccion1;
        private int[] seccion2;

        public void Cargar()
        {
            Console.Write("Ingrese la cantidad de estudiantes: ");
            string linea;
            linea = Console.ReadLine();
            int n = int.Parse(linea);
            seccion1 = new int[n];
            seccion2 = new int[n];

            Console.WriteLine("Ingrese notas de la seccion A");
            for (int i = 0; i < seccion1.Length; i++)
            {
                Console.WriteLine("Ingrese Nota estudiante [" + (i + 1) + "]: ");
                linea = Console.ReadLine();
                seccion1[i] = int.Parse(linea);

                if (seccion1[i] >= 65)
                {
                    aprobadosSeccion1++;
                }
                else
                {
                    desaprobadosSeccion1++;
                }
                if (seccion1[i] >= 90)
                {
                    sobresalientes = sobresalientes + 1;
                }
                if (seccion1[i] >= 70)
                {
                    notaRegular = notaRegular + 1;
                }
                promedio1 = promedio1 + seccion1[i];

            }

            aprobadosSeccion1 = (aprobadosSeccion1 * 100) / seccion1.Length;
            Console.WriteLine("El porciento de los aprobados es igual a: " + aprobadosSeccion1 + "");
            desaprobadosSeccion1 = (desaprobadosSeccion1 * 100) / seccion1.Length;
            Console.WriteLine("El porciento de los desaprobados es igual a: " + desaprobadosSeccion1 + "");

            promedio1 = (promedio1) / seccion1.Length;
            Console.WriteLine("El promedio de la seccion1 es igual: " + promedio1 + "");




            Console.WriteLine("Ingrese notas de la seccion2: ");
            for (int j = 0; j < seccion2.Length; j++)
            {
                Console.WriteLine("Ingrese Nota estudiante [" + (j + 1) + "]: ");
                linea = Console.ReadLine();
                seccion2[j] = int.Parse(linea);

                if (seccion2[j] >= 65)
                {
                    aprobadosSeccion2++;
                }
                else
                {
                    desaprobadosSeccion2++;
                }
                if (seccion2[j] >= 90)
                {
                    sobresalientes = sobresalientes + 1;
                }
                if (seccion2[j] >= 70)
                {
                    notaRegular = notaRegular + 1;
                }

                promedio2 = promedio2 + seccion2[j];
            }
            aprobadosSeccion2 = (aprobadosSeccion2 * 100) / seccion2.Length;
            Console.WriteLine("El porciento de los aprobados es igual a: " + aprobadosSeccion2 + "");
            desaprobadosSeccion2 = (desaprobadosSeccion2 * 100) / seccion2.Length;
            Console.WriteLine("El porciento de los desaprobados es igual a: " + desaprobadosSeccion2 + "");

            promedio2 = (promedio2) / seccion2.Length;
            Console.WriteLine("El promedio de la seccion2 es igual: " + promedio2 + "");

            seccion1y2Aprobados = (aprobadosSeccion1 + aprobadosSeccion2) / 2;
            Console.WriteLine("El porciento de los aprobados de las dos secciones es igual a: " + seccion1y2Aprobados + "");
            seccion1y2Desaprobados = (desaprobadosSeccion1 + desaprobadosSeccion2) / 2;
            Console.WriteLine("El porciento de los desaprobados de las dos secciones es igual a: " + seccion1y2Desaprobados + "");

            promedioSeccion1y2 = (promedio1 + promedio2) / 2;
            Console.WriteLine("El promedio de las dos secciones es igual: " + promedioSeccion1y2 + "");


            Console.WriteLine("La cantidad de personas que sacaron mas de 90: " + sobresalientes + "");
            Console.WriteLine("La cantidad de personas que sacaron mas de 70: " + notaRegular + "");

            Console.ReadKey();
        }
        public void Visualizar()
        {

        }
        static void Main(string[] args)
        {
            PruebaVector pv = new PruebaVector();
            pv.Cargar();

        }
    }
}