﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal_Mario_Darnnel
{
    class Program
    {
        static void Main(string[] args)
        {
            int menuPrincipal;
            int menuHabitacion1;
            int menuHabitacion2;
            
            string Hora = Convert.ToString(DateTime.Now.ToString("HH:mm"));
           
            
            
        //Primera Vista
        CicloVolverHabitacion2:
            Console.WriteLine("Que numero de habitacion quiere elegir: " +
             "\n1.- Habitacion 1" +
             "\n2.- Habitacion 2");
            menuPrincipal = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            switch (menuPrincipal)
            {
                case 1:
                //Ciclo 1 para que te permita volver a elegir otra opción que quieras modificar
                Ciclo:
                    Console.WriteLine("Estas en la primera habitacion 1");
                    //Menu de habitacion 1
                    Console.WriteLine("Eliga una opcion: " +
                     "\n1.- Ventilación" +
                     "\n2.- Calefacción" +
                     "\n3.- Iluminación" +
                     "\n4.- Panel de Control");

                    int humedaHabitacion1 = 0;
                    int temperaturaMaximaHabitacion1 = 0;
                    int temperaturaMinimaHabitacion1 = 0;
                    int ConfirmacionTemperaturaHabitacion1 = 0;
                    Random HumedadHabitacion1 = new Random();
                    menuHabitacion1 = Convert.ToInt32(Console.ReadLine());
                    //Menu
                    switch (menuHabitacion1)
                    {
                        //Menu principal
                        case 1:
                            Console.Clear();
                            Console.WriteLine("¡No tiene acceso a la Ventilación!");
                            
                            goto Ciclo;
                        case 2:
                            Console.Clear();
                            Console.WriteLine("¡No tiene acceso a la Calefacción!");
                            goto Ciclo;
                        case 3:
                            Console.Clear();
                            Console.WriteLine("¡No tiene acceso a la Iluminación!");
                            goto Ciclo;

                        //Panel de control  
                        case 4:

                        //Ciclo 2 para que te permita volver a elegir otra opción que quieras modificar
                        Ciclo2:
                            Console.Clear();
                            Console.WriteLine("Eliga una opción que quiera modificar: " +
                                 "\n1.- Programar a que hora quiere encender y apagar el sistema de ventilación" +
                                 "\n2.- Temperatura máxima y mínima de la calefacción" +
                                 "\n3.- Debe mostar el promedio de las temperaturas máxima y mínima" +
                                 "\n4.- Volver al menu principal");
                            
                            int PanelDeControl;
                            PanelDeControl = Convert.ToInt32(Console.ReadLine());
                            switch (PanelDeControl)
                            {
                                //Programar a que hora quiere encender y apagar el sistema de ventilación"
                                case 1:

                                    //Declaración de vectores para encender y apagar la luz
                                     string[] EncenderVentilacionHabitacion1 = new string[5];
                                    string[] ApagarVentilacionHabitacion1 = new string[5];
                                    
                                   
                                    //Variables de validación de la hora por medio de subcadenas
                                    string EncenderHorahabitacion1;
                                    int PrimerasDosHorasEncendidoHabitacion1;
                                    string ApagarhoraDeHabitacion1;
                                    int PrimerasDoshorasApagadosHabitacion1;
                                    string DospuntosEncenderHabitacion1;
                                    string DospuntosapagarHabitacion1;
                                    //Validaciones de hora de encendido
                                    for (int i = 0; i < 1; i++)
                                    {
                                        Console.WriteLine("A que hora quiere que el sistema este encendido: ");
                                        EncenderVentilacionHabitacion1[i] = Console.ReadLine();
                                        EncenderHorahabitacion1 = EncenderVentilacionHabitacion1[i].Substring(0, 2);
                                        PrimerasDosHorasEncendidoHabitacion1 = Convert.ToInt32(EncenderHorahabitacion1);
                                        DospuntosEncenderHabitacion1 = EncenderVentilacionHabitacion1[i].Substring(2, 1);
                                        Console.WriteLine(DospuntosEncenderHabitacion1);


                                        while (PrimerasDosHorasEncendidoHabitacion1 < 1 || PrimerasDosHorasEncendidoHabitacion1 > 24)
                                        {
                                            Console.WriteLine("Error, colocó una hora erronea, vuelva a intentarlo:  ");
                                            Console.Write("A que hora quiere que el sistema este encendido: ");
                                            EncenderVentilacionHabitacion1[i] = Console.ReadLine();
                                            EncenderHorahabitacion1 = EncenderVentilacionHabitacion1[i].Substring(0, 2);
                                            PrimerasDosHorasEncendidoHabitacion1 = Convert.ToInt32(EncenderHorahabitacion1);
                                        }
                                        while (DospuntosEncenderHabitacion1 != ":")
                                        {
                                            Console.WriteLine("Error, colocó una hora erronea, verifique de colocar los dos puntos, vuelva a intentarlo:  ");
                                            Console.Write("\n ¿A qué hora desea encender la ventilación?: ");
                                            EncenderVentilacionHabitacion1[i] = Console.ReadLine();
                                            DospuntosEncenderHabitacion1 = EncenderVentilacionHabitacion1[i].Substring(2, 1);
                                        }
                                    }
                                   
                                    //Validaciones de hora de apagado
                                    for (int i = 0; i < 1; i++)
                                    {
                                        Console.Write("A que hora quiere que el sistema se apague: ");
                                        ApagarVentilacionHabitacion1[i] = Console.ReadLine();
                                        ApagarhoraDeHabitacion1 = ApagarVentilacionHabitacion1[i].Substring(0, 2);
                                        PrimerasDoshorasApagadosHabitacion1 = Convert.ToInt32(ApagarhoraDeHabitacion1);
                                        DospuntosapagarHabitacion1 = ApagarVentilacionHabitacion1[i].Substring(2, 1);
                                        Console.WriteLine(DospuntosapagarHabitacion1);


                                        while (PrimerasDoshorasApagadosHabitacion1 < 1 || PrimerasDoshorasApagadosHabitacion1 > 24)
                                        {
                                            Console.WriteLine("Error, colocó una hora erronea, verifique de colocar los dos puntos, vuelva a intentarlo:  ");
                                            Console.WriteLine("A que hora quiere que el sistema se apague: ");
                                            ApagarVentilacionHabitacion1[i] = Console.ReadLine();
                                            ApagarhoraDeHabitacion1 = ApagarVentilacionHabitacion1[i].Substring(0, 2);
                                            PrimerasDoshorasApagadosHabitacion1 = Convert.ToInt32(ApagarhoraDeHabitacion1);
                                        }
                                        while (DospuntosapagarHabitacion1 != ":")
                                        {
                                            Console.WriteLine("Error, colocó una hora erronea, verifique de colocar los dos puntos, vuelva a intentarlo:  ");
                                            Console.WriteLine("A que hora quiere que el sistema se apague: ");
                                            ApagarVentilacionHabitacion1[i] = Console.ReadLine();
                                            DospuntosapagarHabitacion1 = ApagarVentilacionHabitacion1[i].Substring(2, 1);

                                        }
                                    }
                                    for (int i = 0; i < 1; i++)
                                    {
                                        if (EncenderVentilacionHabitacion1[i] == Hora)
                                        {
                                            Console.WriteLine("\nLa ventilación está encendida");
                                        }
                                        else
                                        {
                                            Console.WriteLine("\nLa ventilación se encuentra apagada actualmente. ");
                                            Console.WriteLine("La ventilación se encenderá a las " + EncenderVentilacionHabitacion1[i] + " horas");
                                        }
                                    }


                                    for (int i = 0; i < 1; i++)
                                    {

                                        humedaHabitacion1 = HumedadHabitacion1.Next(80);
                                        if (humedaHabitacion1 >= 70)
                                        {
                                            Console.WriteLine("La humeda esta en: " + humedaHabitacion1 + "% por lo que esta encendida la ventilacion");
                                        }
                                        else
                                        {
                                            Console.WriteLine("La humedad esta en: " + humedaHabitacion1 + "% por lo que la ventilacion esta apagada");
                                        }

                                    }

                                    Console.ReadKey();
                                    Console.Clear();
                                    //Ciclo 2 para que te permita volver a elegir otra cosa  que quieras modificar
                                    goto Ciclo2;

                                //Temperatura maxima y minima de la calefacción
                                case 2:

                                    //Pedir Temperatura máxima
                                    Console.WriteLine("A que temperatura máxima desea que este la habitacion: ");
                                    temperaturaMaximaHabitacion1 = Convert.ToInt32(Console.ReadLine());
                                    //Validación de temperatura máxima (No puede ser menor a 18 , restricción)
                                    while (temperaturaMaximaHabitacion1 < 18)
                                    {
                                        Console.WriteLine("Error, colocó una temperatura muy baja, vuelva a intentar:  ");
                                        temperaturaMaximaHabitacion1 = Convert.ToInt32(Console.ReadLine());
                                    }
                                    //Validación de temperatura máxima (No puede ser mayor a 22 grados ¡Advertir que es muy alta!)
                                    if (temperaturaMaximaHabitacion1 > 22)
                                    {
                                        //Advertencia de que la temperatura es muy alta
                                        Console.WriteLine("Usted esta colocando una temperatura alta, desea continuar? 1. Si, 2. No");
                                        ConfirmacionTemperaturaHabitacion1 = Convert.ToInt32(Console.ReadLine());
                                        //Si la persona quiere cambiar temperatura que puede hacerlo
                                        if (ConfirmacionTemperaturaHabitacion1 == 2)
                                        {
                                            Console.WriteLine("A que temperatura máxima desea que este la habitacion: ");
                                            temperaturaMaximaHabitacion1 = Convert.ToInt32(Console.ReadLine());
                                        }


                                    }
                                    //Pedir Temperatura Mínima
                                    Console.WriteLine("A que temperatura mínima desea que este la habitacion: ");
                                    temperaturaMinimaHabitacion1 = Convert.ToInt32(Console.ReadLine());
                                    //Validación de temperatura mínima
                                    while (temperaturaMinimaHabitacion1 < 18)
                                    {
                                        Console.WriteLine("Error, coloco una temperatura muy baja, vuelva a intentar:  ");
                                        temperaturaMinimaHabitacion1 = Convert.ToInt32(Console.ReadLine());
                                    }
                                    //La temperatura mínima obviamente no puede ser mayor a la temperatura maxima 
                                    while (temperaturaMaximaHabitacion1 < temperaturaMinimaHabitacion1)
                                    {
                                        Console.WriteLine("Error, La temperatura minima es mayor a la temperatura maxima, vuelva a intentarlo:  ");
                                        temperaturaMinimaHabitacion1 = Convert.ToInt32(Console.ReadLine());
                                    }

                                    //Mostrar los datos ingresados
                                    Console.WriteLine("La Temperatura Máxima es: " + temperaturaMaximaHabitacion1);
                                    Console.WriteLine("La temperatura Mínima es: " + temperaturaMinimaHabitacion1);

                                    //Ciclo 2 para que te permita volver a elegir otra opción que quieras modificar
                                    Console.ReadKey();
                                    Console.Clear();
                                    goto Ciclo2;

                                //Debe mostar el promedio de las temperaturas máximas y mínimas
                                case 3:
                                    Double promedioHabitacion1 = 0;
                                    //Promedio de las temperaturas máximas y mínimas
                                    promedioHabitacion1 = (temperaturaMaximaHabitacion1 + temperaturaMinimaHabitacion1) / 2;
                                    //Mostrar promedio:
                                    Console.WriteLine("El promedio de la temperatura máxima y mínima es:" + promedioHabitacion1);
                                    Console.ReadKey();
                                    Console.Clear();
                                    goto Ciclo2;

                                    //volver al menu principal
                                    case 4:
                                    goto CicloVolverHabitacion2;
                               
                                //El default funciona por si el usuario elige una opción que no es válida o no existe
                                default:
                                    Console.WriteLine("¡Ha seleccionado una opción que no existe!");

                                    //Ciclo 2 para que te permita volver a elegir otra opción que quieras modificar
                                    Console.ReadKey();
                                    goto Ciclo2;
                            }

                            goto Ciclo;
                        //El default funciona por si el usuario elige una opción que no es válida o no existe
                        default:
                            Console.WriteLine("¡Ha seleccionado una opción que no existe!");
                            goto Ciclo;
                    }
                    Console.ReadKey();

                    break;
                case 2:
                //Ciclo 1 para que te permita volver a elegir otra opción que quieras modificar
                CicloHabitacion2:

                    Console.WriteLine("Estas en la habitacion 2");
                    //Primera vista de usuario 
                    Console.WriteLine("Eliga una opcion: " +
                     "\n1.- Ventilación" +
                     "\n2.- Calefacción" +
                     "\n3.- Iluminación" +
                     "\n4.- Panel de Control");


                    int humedaHabitacion2 = 0;
                    int temperaturaMaximaHabitacion2 = 0;
                    int temperaturaMinimaHabitacion2 = 0;
                    int ConfirmacionTemperaturaHabitacion2 = 0;
                    Random humedad2 = new Random();
                    menuHabitacion2 = Convert.ToInt32(Console.ReadLine());
                    //Menu
                    switch (menuHabitacion2)
                    {
                        //Menu principal
                        case 1:
                            Console.Clear();
                            Console.WriteLine("¡No tiene acceso a la Ventilación!");
                            goto CicloHabitacion2;
                        case 2:
                            Console.Clear();
                            Console.WriteLine("¡No tiene acceso a la Calefacción!");
                            goto CicloHabitacion2;
                        case 3:
                            Console.Clear();
                            Console.WriteLine("¡No tiene acceso a la Iluminación!");
                            goto CicloHabitacion2;

                        //Panel de control  
                        case 4:

                        //Ciclo 2 para que te permita volver a elegir otra opción que quieras modificar
                        Ciclo2Habitacion2:

                            Console.WriteLine("Eliga una opción que quiera modificar: " +
                                 "\n1.- Programar a que hora quiere encender y apagar el sistema de ventilación" +
                                 "\n2.- Temperatura máxima y mínima de la calefacción" +
                                 "\n3.- Debe mostar el promedio de las temperaturas máxima y mínima" +
                                 "\n3.- Volver al menu principal");
                            int PanelDeControl;
                            PanelDeControl = Convert.ToInt32(Console.ReadLine());
                            switch (PanelDeControl)
                            {
                                //Programar a que hora quiere encender y apagar el sistema de ventilación"
                                case 1:
                                    //Declaración de vectores para encender y apagar la luz
                                    string[] EncenderVentilacionHabitacion2 = new string[5];
                                    string[] ApagarVentilacionHabitacion2 = new string[5];


                                    //Variables de validación de la hora por medio de subcadenas
                                    string EncenderHorahabitacion2;
                                    int PrimerasDosHorasEncendidoHabitacion2;
                                    string ApagarhoraDeHabitacion2;
                                    int PrimerasDoshorasApagadosHabitacion2;
                                    string DospuntosEncenderHabitacion2;
                                    string DospuntosapagarHabitacion2;
                                    //Validaciones de hora de encendido
                                    for (int i = 0; i < 1; i++)
                                    {
                                        Console.WriteLine("A que hora quiere que el sistema este encendido: ");
                                        EncenderVentilacionHabitacion2[i] = Console.ReadLine();
                                        EncenderHorahabitacion2 = EncenderVentilacionHabitacion2[i].Substring(0, 2);
                                        PrimerasDosHorasEncendidoHabitacion2 = Convert.ToInt32(EncenderHorahabitacion2);
                                        DospuntosEncenderHabitacion2 = EncenderVentilacionHabitacion2[i].Substring(2, 1);
                                        Console.WriteLine(DospuntosEncenderHabitacion2);


                                        while (PrimerasDosHorasEncendidoHabitacion2 < 1 || PrimerasDosHorasEncendidoHabitacion2 > 24)
                                        {
                                            Console.WriteLine("Error, colocó una hora erronea, vuelva a intentarlo:  ");
                                            Console.Write("A que hora quiere que el sistema este encendido: ");
                                            EncenderVentilacionHabitacion2[i] = Console.ReadLine();
                                            EncenderHorahabitacion2 = EncenderVentilacionHabitacion2[i].Substring(0, 2);
                                            PrimerasDosHorasEncendidoHabitacion2 = Convert.ToInt32(EncenderHorahabitacion2);
                                        }
                                        while (DospuntosEncenderHabitacion2 != ":")
                                        {
                                            Console.WriteLine("Error, colocó una hora erronea, verifique de colocar los dos puntos, vuelva a intentarlo:  ");
                                            Console.Write("\n ¿A qué hora desea encender la ventilación?: ");
                                            EncenderVentilacionHabitacion2[i] = Console.ReadLine();
                                            DospuntosEncenderHabitacion2 = EncenderVentilacionHabitacion2[i].Substring(2, 1);
                                        }
                                    }

                                    //Validaciones de hora de apagado
                                    for (int i = 0; i < 1; i++)
                                    {
                                        Console.Write("A que hora quiere que el sistema se apague: ");
                                        ApagarVentilacionHabitacion2[i] = Console.ReadLine();
                                        ApagarhoraDeHabitacion2 = ApagarVentilacionHabitacion2[i].Substring(0, 2);
                                        PrimerasDoshorasApagadosHabitacion2 = Convert.ToInt32(ApagarhoraDeHabitacion2);
                                        DospuntosapagarHabitacion2 = ApagarVentilacionHabitacion2[i].Substring(2, 1);
                                        Console.WriteLine(DospuntosapagarHabitacion2);


                                        while (PrimerasDoshorasApagadosHabitacion2 < 1 || PrimerasDoshorasApagadosHabitacion2 > 24)
                                        {
                                            Console.WriteLine("Error, colocó una hora erronea, verifique de colocar los dos puntos, vuelva a intentarlo:  ");
                                            Console.WriteLine("A que hora quiere que el sistema se apague: ");
                                            ApagarVentilacionHabitacion2[i] = Console.ReadLine();
                                            ApagarhoraDeHabitacion2 = ApagarVentilacionHabitacion2[i].Substring(0, 2);
                                            PrimerasDoshorasApagadosHabitacion2 = Convert.ToInt32(ApagarhoraDeHabitacion2);
                                        }
                                        while (DospuntosapagarHabitacion2 != ":")
                                        {
                                            Console.WriteLine("Error, colocó una hora erronea, verifique de colocar los dos puntos, vuelva a intentarlo:  ");
                                            Console.WriteLine("A que hora quiere que el sistema se apague: ");
                                            ApagarVentilacionHabitacion2[i] = Console.ReadLine();
                                            DospuntosapagarHabitacion2 = ApagarVentilacionHabitacion2[i].Substring(2, 1);

                                        }
                                    }
                                    for (int i = 0; i < 1; i++)
                                    {
                                        if (EncenderVentilacionHabitacion2[i] == Hora)
                                        {
                                            Console.WriteLine("\nLa ventilación está encendida");
                                        }
                                        else
                                        {
                                            Console.WriteLine("\nLa ventilación se encuentra apagada actualmente. ");
                                            Console.WriteLine("La ventilación se encenderá a las " + EncenderVentilacionHabitacion2[i] + " horas");
                                        }
                                    }
                                    for (int i = 0; i < 1; i++)
                                    {

                                        humedaHabitacion2 = humedad2.Next(80);
                                        if (humedaHabitacion2 >= 70)
                                        {
                                            Console.WriteLine("La humeda esta en: " + humedaHabitacion2 + "% por lo que esta encendida la ventilacion");
                                        }
                                        else
                                        {
                                            Console.WriteLine("La humedad esta en: " + humedaHabitacion2 + "% por lo que la ventilacion esta apagada");
                                        }

                                    }
                                    Console.ReadKey();
                                    Console.Clear();
                                    //Ciclo 2 para que te permita volver a elegir otra cosa  que quieras modificar
                                    goto Ciclo2Habitacion2;

                                //Temperatura maxima y minima de la calefacción
                                case 2:

                                    //Pedir Temperatura máxima
                                    Console.WriteLine("A que temperatura máxima desea que este la habitacion: ");
                                    temperaturaMaximaHabitacion2 = Convert.ToInt32(Console.ReadLine());
                                    //Validación de temperatura máxima (No puede ser menor a 18 , restricción)
                                    while (temperaturaMaximaHabitacion2 < 18)
                                    {
                                        Console.WriteLine("Error, colocó una temperatura muy baja, vuelva a intentar:  ");
                                        temperaturaMaximaHabitacion2 = Convert.ToInt32(Console.ReadLine());
                                    }
                                    //Validación de temperatura máxima (No puede ser mayor a 22 grados ¡Advertir que es muy alta!)
                                    if (temperaturaMaximaHabitacion2 > 22)
                                    {
                                        //Advertencia de que la temperatura es muy alta
                                        Console.WriteLine("Usted esta colocando una temperatura alta, desea continuar? 1. Si, 2. No");
                                        ConfirmacionTemperaturaHabitacion2 = Convert.ToInt32(Console.ReadLine());
                                        //Si la persona quiere cambiar temperatura que puede hacerlo
                                        if (ConfirmacionTemperaturaHabitacion2 == 2)
                                        {
                                            Console.WriteLine("A que temperatura máxima desea que este la habitacion: ");
                                            temperaturaMaximaHabitacion2 = Convert.ToInt32(Console.ReadLine());
                                        }


                                    }
                                    //Pedir Temperatura Mínima
                                    Console.WriteLine("A que temperatura mínima desea que este la habitacion: ");
                                    temperaturaMinimaHabitacion2 = Convert.ToInt32(Console.ReadLine());
                                    //Validación de temperatura mínima
                                    while (temperaturaMinimaHabitacion2 < 18)
                                    {
                                        Console.WriteLine("Error, coloco una temperatura muy baja, vuelva a intentar:  ");
                                        temperaturaMinimaHabitacion2 = Convert.ToInt32(Console.ReadLine());
                                    }
                                    //La temperatura mínima obviamente no puede ser mayor a la temperatura maxima 
                                    while (temperaturaMaximaHabitacion2 < temperaturaMinimaHabitacion2)
                                    {
                                        Console.WriteLine("Error, La temperatura minima es mayor a la temperatura maxima, vuelva a intentarlo:  ");
                                        temperaturaMinimaHabitacion2 = Convert.ToInt32(Console.ReadLine());
                                    }

                                    //Mostrar los datos ingresados
                                    Console.WriteLine("La Temperatura Máxima es: " + temperaturaMaximaHabitacion2);
                                    Console.WriteLine("La temperatura Mínima es: " + temperaturaMinimaHabitacion2);

                                    //Ciclo 2 para que te permita volver a elegir otra opción que quieras modificar
                                    Console.ReadKey();
                                    Console.Clear();
                                    goto Ciclo2Habitacion2;

                                //Debe mostar el promedio de las temperaturas máximas y mínimas
                                case 3:
                                    
                                    //Promedio de las temperaturas máximas y mínimas
                                    Double promedioHabitacion1 = (temperaturaMaximaHabitacion2 + temperaturaMinimaHabitacion2) / 2;
                                    //Mostrar promedio:
                                    Console.WriteLine("El promedio de la temperatura máxima y mínima es: " + promedioHabitacion1);
                                    Console.ReadKey();
                                    Console.Clear();
                                    goto Ciclo2Habitacion2;

                                //volver al menu principal
                                case 4:
                                    goto CicloVolverHabitacion2;

                                //El default funciona por si el usuario elige una opción que no es válida o no existe
                                default:
                                    Console.WriteLine("¡Ha seleccionado una opción que no existe!");

                                    //Ciclo 2 para que te permita volver a elegir otra opción que quieras modificar
                                    Console.ReadKey();

                                    goto Ciclo2Habitacion2;
                            }

                            goto CicloHabitacion2;
                        //El default funciona por si el usuario elige una opción que no es válida o no existe
                        default:
                            Console.WriteLine("¡Ha seleccionado una opción que no existe!");
                            goto CicloHabitacion2;
                    }
                    Console.ReadKey();
                    break;
                default:
                    Console.WriteLine("¡Ha seleccionado una opción que no existe!");
                    break;
                    
            }
            

        }
    }
}

