﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10_DG_1280022
{
    class Program
    {
        static bool login(string usuario, string contrasena)
        {
            if (usuario == "usuario1" && contrasena == "asdasd")
            {
                return true;

            }
            else
            {
                return false;
            }

        }
        static void Main(string[] args)
        {
            int i = 0;
            while (i < 3)
            {
                string usuario = "";
                string contrasena = "";
bool x;

Console.WriteLine("INGRESE USUARIO");

usuario = Console.ReadLine();

Console.WriteLine("INGRESE CONTRASEÑA");
contrasena = Console.ReadLine();

x = login(usuario, contrasena);
if (x == true)
{
    i = 3;
    Console.WriteLine("Ingresó con Exito");

}
else
{
    i++;
    if (i < 3)
    {
        Console.WriteLine("Intento fallido, intente nuevamente");

    }
    else
    {
        Console.WriteLine("Fail, limite de intentos alcanzado");
    }

}
            }
            Console.ReadKey();
            }
        }
    }