﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1_DG_1280022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola Mundo Soy Darnnel Gonzalez");
            Console.ReadKey();

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("Soy Darnnel Gonzalez");

            /*La unica diferencia esque el Console.Writeline coloca el mensaje linea por linea tal como lo escribimos por asi decirlo, mientras que el 
              Console.Write lo coloca todo en una misma linea*/
            Console.Write("Hola Mundo");
            Console.Write("Soy Darnnel Gonzalez");
            Console.ReadKey();

            Console.WriteLine("Ingrese su nombre: ");
            string Nombre = Console.ReadLine();

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy" + Nombre);

            /*La unica diferencia esque el Console.Writeline coloca el mensaje linea por linea mientras que el 
              Console.Write lo coloca todo en una misma linea*/
            Console.Write("Hola Mundo");
            Console.Write("soy" + Nombre);
            Console.ReadKey();
        }
    }
}